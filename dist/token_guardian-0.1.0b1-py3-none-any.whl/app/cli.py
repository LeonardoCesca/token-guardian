from __future__ import annotations

import argparse
import json
import sys
from collections.abc import Sequence
from dataclasses import dataclass

from InquirerPy import inquirer
from rich import box
from rich.console import Console
from rich.console import Group
from rich.markdown import Markdown
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from app.models.schemas import (
    LLMMessage,
    ReviewSessionCreateRequest,
    ReviewSessionInvokeRequest,
)
from app.providers.registry import list_models
from app.services.llm_gateway_service import (
    GatewayDependencyError,
    invoke_reviewed_session,
)
from app.services.metrics_service import get_metrics
from app.services.review_session_service import (
    ReviewSessionNotFoundError,
    create_review_session,
    get_review_session,
)


@dataclass(frozen=True, slots=True)
class HostProfile:
    id: str
    label: str
    providers: tuple[str, ...]
    description: str


HOST_PROFILES: tuple[HostProfile, ...] = (
    HostProfile(
        id="claude-code",
        label="Claude Code",
        providers=("anthropic",),
        description="Sugestoes focadas em modelos Anthropic.",
    ),
    HostProfile(
        id="codex",
        label="Codex",
        providers=("openai", "openrouter"),
        description="Sugestoes focadas em modelos OpenAI e OpenRouter.",
    ),
    HostProfile(
        id="github-copilot",
        label="GitHub Copilot",
        providers=("openai", "anthropic", "google"),
        description="Sugestoes amplas para um fluxo estilo Copilot.",
    ),
)
CONSOLE = Console()
ASCII_LOGO = r"""
   _______    _                 _____                     _ _             
  |__   __|  | |               / ____|                   | (_)            
     | | ___ | | _____ _ __   | |  __ _   _  __ _ _ __ __| |_  __ _ _ __  
     | |/ _ \| |/ / _ \ '_ \  | | |_ | | | |/ _` | '__/ _` | |/ _` | '_ \ 
     | | (_) |   <  __/ | | | | |__| | |_| | (_| | | | (_| | | (_| | | | |
     |_|\___/|_|\_\___|_| |_|  \_____|\__,_|\__,_|_|  \__,_|_|\__,_|_| |_|

                            [ shielded prompt preflight ]
"""


def main(argv: Sequence[str] | None = None) -> int:
    raw_argv = list(argv) if argv is not None else sys.argv[1:]
    if not raw_argv:
        return _menu_command(argparse.Namespace())

    parser = _build_parser()
    args = parser.parse_args(raw_argv)
    return args.func(args)


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="token-guardian",
        description="Guardrail-first CLI for LLM prompts.",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    menu_parser = subparsers.add_parser("menu", help="Open the interactive menu.")
    menu_parser.set_defaults(func=_menu_command)

    models_parser = subparsers.add_parser(
        "models", help="List supported provider/model combinations."
    )
    models_parser.set_defaults(func=_models_command)

    metrics_parser = subparsers.add_parser("metrics", help="Show local usage metrics.")
    metrics_parser.set_defaults(func=_metrics_command)

    review_parser = subparsers.add_parser("review", help="Create a review session.")
    review_parser.add_argument("--provider", required=True)
    review_parser.add_argument("--model", required=True)
    review_parser.add_argument("--prompt", required=True)
    review_parser.add_argument("--estimated-output-tokens", type=int)
    review_parser.set_defaults(func=_review_command)

    status_parser = subparsers.add_parser("status", help="Show session status.")
    status_parser.add_argument("session_id")
    status_parser.set_defaults(func=_status_command)

    invoke_parser = subparsers.add_parser(
        "invoke", help="Call the reviewed LLM session via LiteLLM."
    )
    invoke_parser.add_argument("session_id")
    invoke_parser.add_argument("--system")
    invoke_parser.add_argument("--message", action="append", default=[])
    invoke_parser.add_argument("--temperature", type=float)
    invoke_parser.add_argument("--max-tokens", type=int)
    invoke_parser.set_defaults(func=_invoke_command)

    return parser


def _menu_command(_args: argparse.Namespace) -> int:
    _render_cover()

    while True:
        choice = _prompt_single_selection(
            message="Token Guardian CLI",
            choices=[
                {
                    "name": "Revisar prompt",
                    "value": "review",
                    "description": "Analisa o prompt e mostra o resumo.",
                },
                {
                    "name": "Ver metricas",
                    "value": "metrics",
                    "description": "Resumo local de uso e custo estimado.",
                },
                {
                    "name": "Listar modelos suportados",
                    "value": "models",
                    "description": "Mostra o catalogo carregado pelo CLI.",
                },
                {
                    "name": "Sair",
                    "value": "exit",
                    "description": "Fecha o Token Guardian.",
                },
            ],
            instruction="Use espaco para marcar uma opcao e Enter para confirmar.",
        )

        if choice == "review":
            exit_code = _interactive_review()
        elif choice == "metrics":
            exit_code = _metrics_command(argparse.Namespace())
        elif choice == "models":
            exit_code = _models_command(argparse.Namespace())
        elif choice == "exit":
            print("Encerrando Token Guardian.")
            return 0
        else:
            print("Opcao invalida. Escolha um item valido.")
            continue

        if exit_code != 0:
            print("\nA operacao terminou com aviso ou erro.")


def _interactive_review() -> int:
    host_profile = _choose_host_profile()
    selected_model = _choose_model(host_profile)
    if selected_model is None:
        print("Operacao cancelada.")
        return 1

    prompt = _read_prompt()
    if not prompt:
        print("Nenhum prompt informado.")
        return 1

    estimated_output_tokens = None
    args = argparse.Namespace(
        provider=selected_model.provider,
        model=selected_model.model,
        prompt=prompt,
        estimated_output_tokens=estimated_output_tokens,
    )

    return _review_and_maybe_cancel(args)


def _review_and_maybe_cancel(args: argparse.Namespace) -> int:
    response = create_review_session(
        ReviewSessionCreateRequest(
            provider=args.provider,
            model=args.model,
            prompt=args.prompt,
            estimated_output_tokens=args.estimated_output_tokens,
        )
    )
    _render_session_markdown(response.session_id, response.markdown, "Analise")
    return 0


def _models_command(_args: argparse.Namespace) -> int:
    table = _build_styled_table("Modelos suportados", "bright_cyan")
    table.add_column("#", style="dim")
    table.add_column("Modelo", style="bold")
    table.add_column("Provider")
    table.add_column("Contexto", justify="right")
    table.add_column("Velocidade")
    for index, config in enumerate(
        sorted(list_models(), key=lambda item: (item.provider, item.model)), start=1
    ):
        table.add_row(
            str(index),
            config.display_name,
            f"{config.provider}/{config.model}",
            str(config.context_limit),
            config.speed_estimate,
        )
    CONSOLE.print(table)
    return 0


def _metrics_command(_args: argparse.Namespace) -> int:
    metrics = get_metrics()
    summary = _build_styled_table("Metricas locais", "bright_cyan", show_header=False)
    summary.add_column("Campo", style="bold cyan")
    summary.add_column("Valor")
    summary.add_row("Total de requisicoes", str(metrics.total_requests))
    summary.add_row("Total de tokens", str(metrics.total_tokens))
    summary.add_row("Custo estimado acumulado", f"${metrics.total_cost_estimated:.6f}")
    summary.add_row("Top modelos", _format_ranked_metrics(metrics.top_models))
    summary.add_row("Top providers", _format_ranked_metrics(metrics.top_providers))
    CONSOLE.print(summary)
    return 0


def _review_command(args: argparse.Namespace) -> int:
    response = create_review_session(
        ReviewSessionCreateRequest(
            provider=args.provider,
            model=args.model,
            prompt=args.prompt,
            estimated_output_tokens=args.estimated_output_tokens,
        )
    )
    _render_session_markdown(response.session_id, response.markdown, "Analise")
    return 0


def _status_command(args: argparse.Namespace) -> int:
    try:
        response = get_review_session(args.session_id)
    except ReviewSessionNotFoundError as exc:
        print(str(exc))
        return 1
    _render_json_block("Status da sessao", response.model_dump())
    return 0


def _invoke_command(args: argparse.Namespace) -> int:
    try:
        response = invoke_reviewed_session(
            args.session_id,
            _build_invoke_request(args),
        )
    except (ReviewSessionNotFoundError, GatewayDependencyError) as exc:
        print(str(exc))
        return 1
    _render_content_panel("Resposta da LLM", response.content)
    return 0


def _build_invoke_request(args: argparse.Namespace) -> ReviewSessionInvokeRequest:
    messages: list[LLMMessage] = []
    if getattr(args, "system", None):
        messages.append(LLMMessage(role="system", content=args.system))
    for message in getattr(args, "message", []):
        messages.append(LLMMessage(role="user", content=message))
    return ReviewSessionInvokeRequest(
        messages=messages,
        temperature=getattr(args, "temperature", None),
        max_tokens=getattr(args, "max_tokens", None),
    )


def _choose_host_profile() -> HostProfile:
    while True:
        selected_id = _prompt_single_selection(
            message="Escolha o provider do fluxo",
            choices=[
                {
                    "name": profile.label,
                    "value": profile.id,
                    "description": profile.description,
                }
                for profile in HOST_PROFILES
            ],
            instruction="Use espaco para marcar o provider e Enter para confirmar.",
        )
        for profile in HOST_PROFILES:
            if profile.id == selected_id:
                return profile
        print("Opcao invalida. Escolha um provider valido.")


def _choose_model(host_profile: HostProfile):
    models = sorted(
        [item for item in list_models() if item.provider in host_profile.providers],
        key=lambda item: (item.provider, item.model),
    )
    while True:
        selected_value = _prompt_single_selection(
            message=f"Escolha o modelo para {host_profile.label}",
            choices=[
                {
                    "name": (
                        f"{config.display_name} "
                        f"({config.provider}/{config.model}) - "
                        f"contexto {config.context_limit}"
                    ),
                    "value": f"{config.provider}::{config.model}",
                    "description": f"Velocidade: {config.speed_estimate}",
                }
                for config in models
            ],
            instruction="Use espaco para marcar o modelo e Enter para confirmar.",
        )

        for model in models:
            if f"{model.provider}::{model.model}" == selected_value:
                return model
        print("Opcao invalida. Escolha um modelo valido.")


def _read_prompt() -> str:
    if _supports_interactive_selection():
        return inquirer.text(
            message="Cole o prompt",
            instruction="Pressione Enter para enviar.",
            validate=lambda result: len(str(result).strip()) > 0,
            invalid_message="Informe um prompt antes de continuar.",
            raise_keyboard_interrupt=True,
        ).execute().strip()

    return _safe_input("\nCole o prompt e pressione Enter: ").strip()


def _read_optional_text(prompt: str) -> str:
    if _supports_interactive_selection():
        value = inquirer.text(
            message=prompt,
            instruction="Deixe em branco para pular.",
            mandatory=False,
            raise_keyboard_interrupt=True,
        ).execute()
        if value is None:
            return ""
        return str(value).strip()

    return _safe_input(prompt).strip()


def _read_optional_int(prompt: str) -> int | None:
    while True:
        raw_value = _read_optional_text(prompt)
        if not raw_value:
            return None
        if raw_value.isdigit() and int(raw_value) > 0:
            return int(raw_value)
        print("Digite um numero inteiro positivo ou deixe em branco.")


def _read_optional_float(
    prompt: str, minimum: float | None = None, maximum: float | None = None
) -> float | None:
    while True:
        raw_value = _read_optional_text(prompt)
        if not raw_value:
            return None
        try:
            value = float(raw_value)
        except ValueError:
            print("Digite um numero valido ou deixe em branco.")
            continue
        if minimum is not None and value < minimum:
            print(f"O valor deve ser maior ou igual a {minimum}.")
            continue
        if maximum is not None and value > maximum:
            print(f"O valor deve ser menor ou igual a {maximum}.")
            continue
        return value


def _prompt_single_selection(
    message: str,
    choices: list[dict[str, str]],
    instruction: str,
) -> str | None:
    if _supports_interactive_selection():
        result = inquirer.checkbox(
            message=message,
            choices=[
                {
                    "name": choice["name"],
                    "value": choice["value"],
                    "enabled": False,
                }
                for choice in choices
            ],
            instruction=instruction,
            long_instruction=_build_long_instruction(choices),
            validate=lambda result: len(result) == 1,
            invalid_message="Selecione exatamente uma opcao.",
            cycle=True,
            raise_keyboard_interrupt=True,
        ).execute()
        if not result:
            return None
        return result[0]

    print(f"\n{message}\n")
    for index, choice in enumerate(choices, start=1):
        description = choice.get("description", "")
        suffix = f" - {description}" if description else ""
        print(f"{index}. {choice['name']}{suffix}")
    raw_value = _safe_input("\nEscolha uma opcao pelo numero: ").strip()
    normalized_value = raw_value.lower()
    for choice in choices:
        if normalized_value == str(choice["value"]).lower():
            return choice["value"]
        if normalized_value == str(choice["name"]).lower():
            return choice["value"]
    if not raw_value.isdigit():
        return None
    index = int(raw_value)
    if not 1 <= index <= len(choices):
        return None
    return choices[index - 1]["value"]


def _build_long_instruction(choices: list[dict[str, str]]) -> str:
    descriptions = [
        f"{choice['name']}: {choice['description']}"
        for choice in choices
        if choice.get("description")
    ]
    return "\n".join(descriptions)


def _supports_interactive_selection() -> bool:
    return sys.stdin.isatty() and sys.stdout.isatty()


def _safe_input(prompt: str) -> str:
    try:
        return input(prompt)
    except EOFError:
        return ""
    except KeyboardInterrupt:
        print("\nOperacao interrompida pelo usuario.")
        raise SystemExit(130) from None


def _format_ranked_metrics(items: list[dict[str, int]]) -> str:
    if not items:
        return "nenhum dado ainda"
    formatted: list[str] = []
    for item in items:
        name, count = next(iter(item.items()))
        formatted.append(f"{name} ({count})")
    return ", ".join(formatted)


def _render_session_markdown(session_id: str, markdown: str, title: str) -> None:
    session_header = Text()
    session_header.append("session_id:", style="bold cyan")
    session_header.append(f" {session_id}", style="bold white")

    _render_boxed_block(
        title=title,
        body=Group(session_header, Text(""), Markdown(markdown)),
        border_style="bright_cyan",
        padding=(0, 1),
        expand=True,
    )


def _render_content_panel(title: str, content: str) -> None:
    _render_boxed_block(
        title=title,
        body=Markdown(content),
        border_style="green",
        padding=(1, 2),
        expand=True,
    )


def _render_json_block(title: str, payload: dict[str, object]) -> None:
    _render_boxed_block(
        title=title,
        body=json.dumps(payload, ensure_ascii=False, indent=2),
        border_style="magenta",
        padding=(1, 2),
        expand=True,
    )


def _render_boxed_block(
    title: str,
    body,
    border_style: str,
    padding: tuple[int, int],
    expand: bool,
) -> None:
    CONSOLE.print("")
    CONSOLE.print(
        Panel(
            body,
            title=f"[bold {border_style}]{title}[/bold {border_style}]",
            title_align="center",
            border_style=border_style,
            box=box.ROUNDED,
            padding=padding,
            expand=expand,
        )
    )


def _build_styled_table(
    title: str,
    border_style: str,
    *,
    show_header: bool = True,
) -> Table:
    return Table(
        title=f"[bold {border_style}]{title}[/bold {border_style}]",
        title_justify="center",
        show_header=show_header,
        header_style="bold cyan",
        border_style=border_style,
        box=box.ROUNDED,
        pad_edge=True,
        expand=False,
    )


def _render_cover() -> None:
    _render_boxed_block(
        title="token-guardian",
        body=Text.from_markup(f"[bold bright_cyan]{ASCII_LOGO}[/bold bright_cyan]"),
        border_style="bright_cyan",
        padding=(1, 2),
        expand=True,
    )


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
