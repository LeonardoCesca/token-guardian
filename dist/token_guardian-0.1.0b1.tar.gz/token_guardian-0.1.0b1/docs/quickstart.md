# Quickstart

This project now recommends the CLI as the main way to use Token Guardian.

## Windows

Install:

```powershell
powershell -ExecutionPolicy Bypass -File scripts\install.ps1
```

Run:

```powershell
powershell -File scripts\run-cli.ps1
```

## macOS / Linux

Install:

```bash
bash scripts/install.sh
```

Run:

```bash
bash scripts/run-cli.sh
```

## Expected flow

1. open the menu
2. choose `Revisar prompt` or `Revisar prompt e enviar para LLM`
3. choose the host profile such as `Claude Code`, `Codex`, or `GitHub Copilot`
4. choose a suggested model for that profile
5. paste the prompt and press `Enter`
6. review the markdown analysis
7. if you chose execution mode, the CLI continues to the LLM automatically

Selections in the interactive menu use `espaco` to mark and `Enter` to confirm.

In the interactive flow, output token estimation is automatic.

## Optional direct commands

Review only:

```bash
token-guardian review --provider anthropic --model claude-sonnet-4 --prompt "Revise esta arquitetura."
```

Review and continue after the analysis step:

```bash
token-guardian run --provider anthropic --model claude-sonnet-4 --prompt "Revise esta arquitetura."
```

See supported models:

```bash
token-guardian models
```

See metrics:

```bash
token-guardian metrics
```
