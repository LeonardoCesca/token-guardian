# Integration Strategy

## Current product direction

Token Guardian is now CLI-first.

That means the recommended public experience is:

1. install the package
2. run `token-guardian`
3. review the prompt
4. inspect the analysis
5. continue with the execution flow when appropriate

## Why this direction

The CLI is the most stable way to enforce the gate before the provider call.

Benefits:

- cross-platform
- easy to document
- easy to distribute
- works without editor-specific APIs
- shows the guardrail analysis before the LLM execution flow

## What stays in the project

The project now keeps only:

- the CLI
- local database and metrics
- optional LiteLLM gateway after the analysis step

## Recommended public packaging

For open-source distribution:

1. publish the Python package to PyPI
2. keep GitHub as the source of docs and examples

The main onboarding message becomes simple:

```bash
pip install token-guardian
token-guardian
```

## Future integrations

After the CLI is stable, new integrations can be built on top of it, but they are outside the current scope of this repository.
