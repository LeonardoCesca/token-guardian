# Release Checklist

## Product

- CLI flow matches the public docs
- prompt entry is clear and works with a single `Enter`
- interactive token estimation is automatic
- no legacy confirmation flow remains

## Code

- `pytest` passes
- coverage stays above the configured threshold
- no legacy `token_guardian_mcp` references remain in the repository
- no legacy MCP or VS Code product claims remain in public docs

## Packaging

- `pyproject.toml` version is updated
- `scripts/install.ps1` works on Windows
- `scripts/install.sh` is ready for macOS/Linux
- `token-guardian` command is installed correctly

## Documentation

- `README.md` reflects the real menu and commands
- `docs/quickstart.md` reflects the real prompt flow
- `CHANGELOG.md` is updated
- `CONTRIBUTING.md` is present

## Community

- bug report template exists
- feature request template exists
- release is labeled clearly as alpha or beta when appropriate
