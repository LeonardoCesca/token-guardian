from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace

import pytest

from app import cli
from app.services import database


@pytest.fixture
def isolated_db(monkeypatch, tmp_path: Path) -> Path:
    db_path = tmp_path / "cli_gateway.db"
    monkeypatch.setattr(database, "DB_PATH", db_path)
    database.init_db()
    return db_path


def test_cli_review_prints_session_and_markdown(
    isolated_db: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    exit_code = cli.main(
        [
            "review",
            "--provider",
            "anthropic",
            "--model",
            "claude-sonnet-4",
            "--prompt",
            "Revise esta arquitetura.",
        ]
    )

    output = capsys.readouterr().out
    assert exit_code == 0
    assert "session_id:" in output
    assert "Analise da Resposta" in output


def test_cli_models_prints_table(
    isolated_db: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    exit_code = cli.main(["models"])

    output = capsys.readouterr().out
    assert exit_code == 0
    assert "Modelos suportados" in output


def test_cli_status_returns_error_for_missing_session(
    isolated_db: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    exit_code = cli.main(["status", "missing"])

    output = capsys.readouterr().out
    assert exit_code == 1
    assert "Review session not found" in output


def test_cli_status_prints_json_for_existing_session(
    isolated_db: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    review = cli.create_review_session(
        cli.ReviewSessionCreateRequest(
            provider="anthropic",
            model="claude-sonnet-4",
            prompt="Revise esta arquitetura.",
        )
    )

    exit_code = cli.main(["status", review.session_id])

    output = capsys.readouterr().out
    assert exit_code == 0
    assert '"status": "reviewed"' in output


def test_cli_invoke_prints_content_after_review(
    monkeypatch,
    isolated_db: Path,
    capsys: pytest.CaptureFixture[str],
) -> None:
    review = cli.create_review_session(
        cli.ReviewSessionCreateRequest(
            provider="anthropic",
            model="claude-sonnet-4",
            prompt="Revise esta arquitetura.",
        )
    )
    monkeypatch.setattr(
        cli,
        "invoke_reviewed_session",
        lambda session_id, request: SimpleNamespace(content="Resposta final."),
    )

    exit_code = cli.main(
        ["invoke", review.session_id, "--system", "Responda em portugues."]
    )

    output = capsys.readouterr().out
    assert exit_code == 0
    assert "Resposta final." in output


def test_cli_invoke_returns_error_for_missing_session(
    isolated_db: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    exit_code = cli.main(["invoke", "missing"])

    output = capsys.readouterr().out
    assert exit_code == 1
    assert "Review session not found" in output


def test_cli_status_returns_error_for_missing_session_again(
    isolated_db: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    exit_code = cli.main(["status", "missing"])

    output = capsys.readouterr().out
    assert exit_code == 1
    assert "Review session not found" in output


def test_cli_run_invokes_after_review(
    monkeypatch,
    isolated_db: Path,
    capsys: pytest.CaptureFixture[str],
) -> None:
    monkeypatch.setattr(
        cli,
        "invoke_reviewed_session",
        lambda session_id, request: SimpleNamespace(content="Resposta final."),
    )

    exit_code = cli.main(
        [
            "run",
            "--provider",
            "anthropic",
            "--model",
            "claude-sonnet-4",
            "--prompt",
            "Revise esta arquitetura.",
        ]
    )

    output = capsys.readouterr().out
    assert exit_code == 0
    assert "Resposta da LLM" in output
    assert "Resposta final." in output


def test_cli_run_returns_gateway_error(
    monkeypatch,
    isolated_db: Path,
    capsys: pytest.CaptureFixture[str],
) -> None:
    def fake_invoke(_session_id, _request):
        raise cli.GatewayDependencyError("LiteLLM missing.")

    monkeypatch.setattr(cli, "invoke_reviewed_session", fake_invoke)

    exit_code = cli.main(
        [
            "run",
            "--provider",
            "anthropic",
            "--model",
            "claude-sonnet-4",
            "--prompt",
            "Revise esta arquitetura.",
            "--message",
            "Use bullets.",
        ]
    )

    output = capsys.readouterr().out
    assert exit_code == 1
    assert "LiteLLM missing." in output


def test_build_invoke_request_supports_extra_messages() -> None:
    args = cli.argparse.Namespace(
        system="Responda em portugues.",
        message=["Use bullets."],
        temperature=0.3,
        max_tokens=200,
    )

    request = cli._build_invoke_request(args)

    assert request.messages[0].role == "system"
    assert request.messages[1].content == "Use bullets."


def test_cli_models_lists_supported_models(
    capsys: pytest.CaptureFixture[str],
) -> None:
    exit_code = cli.main(["models"])

    output = capsys.readouterr().out
    assert exit_code == 0
    assert "Modelos suportados" in output
    assert "Claude Sonnet 4" in output


def test_cli_metrics_prints_summary(
    isolated_db: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    cli.main(
        [
            "review",
            "--provider",
            "anthropic",
            "--model",
            "claude-sonnet-4",
            "--prompt",
            "Revise esta arquitetura.",
        ]
    )

    exit_code = cli.main(["metrics"])

    output = capsys.readouterr().out
    assert exit_code == 0
    assert "Metricas locais" in output
    assert "Total de requisicoes" in output


def test_main_without_args_opens_menu(monkeypatch) -> None:
    monkeypatch.setattr(cli, "_menu_command", lambda _args: 7)

    assert cli.main([]) == 7


def test_menu_exits_on_zero(monkeypatch, capsys: pytest.CaptureFixture[str]) -> None:
    monkeypatch.setattr(cli, "_supports_interactive_selection", lambda: False)
    monkeypatch.setattr("builtins.input", lambda _prompt: "5")

    exit_code = cli._menu_command(cli.argparse.Namespace())

    output = capsys.readouterr().out
    assert exit_code == 0
    assert "token-guardian" in output
    assert "Encerrando Token Guardian." in output


def test_menu_handles_invalid_choice_then_exits(
    monkeypatch, capsys: pytest.CaptureFixture[str]
) -> None:
    monkeypatch.setattr(cli, "_supports_interactive_selection", lambda: False)
    answers = iter(["9", "5"])
    monkeypatch.setattr("builtins.input", lambda _prompt: next(answers))

    exit_code = cli._menu_command(cli.argparse.Namespace())

    output = capsys.readouterr().out
    assert exit_code == 0
    assert "Opcao invalida." in output


def test_choose_model_retries_until_valid(
    monkeypatch, capsys: pytest.CaptureFixture[str]
) -> None:
    monkeypatch.setattr(cli, "_supports_interactive_selection", lambda: False)
    answers = iter(["abc", "999", "1"])
    monkeypatch.setattr("builtins.input", lambda _prompt: next(answers))

    model = cli._choose_model(cli.HOST_PROFILES[0])

    output = capsys.readouterr().out
    assert model is not None
    assert "Escolha o modelo para Claude Code" in output
    assert "Opcao invalida. Escolha um modelo valido." in output


def test_choose_host_profile_returns_expected_profile(monkeypatch) -> None:
    monkeypatch.setattr(cli, "_supports_interactive_selection", lambda: False)
    monkeypatch.setattr("builtins.input", lambda _prompt: "2")

    profile = cli._choose_host_profile()

    assert profile.id == "codex"


def test_read_prompt_uses_single_enter_submission(monkeypatch) -> None:
    monkeypatch.setattr(cli, "_supports_interactive_selection", lambda: False)
    monkeypatch.setattr("builtins.input", lambda _prompt: "linha unica")

    assert cli._read_prompt() == "linha unica"


def test_read_optional_int_and_float_helpers(monkeypatch) -> None:
    int_answers = iter(["zero", "", "3"])
    monkeypatch.setattr("builtins.input", lambda _prompt: next(int_answers))
    assert cli._read_optional_int("x") is None

    float_answers = iter(["abc", "3", "1.5"])
    monkeypatch.setattr("builtins.input", lambda _prompt: next(float_answers))
    assert cli._read_optional_float("x", minimum=0.0, maximum=2.0) == 1.5


def test_prompt_single_selection_supports_numeric_choice(monkeypatch) -> None:
    monkeypatch.setattr("builtins.input", lambda _prompt: "1")
    assert (
        cli._prompt_single_selection(
            "Teste",
            [
                {"name": "Alpha", "value": "alpha", "description": "ok"},
                {"name": "Beta", "value": "beta", "description": "stop"},
            ],
            "x",
        )
        == "alpha"
    )


def test_format_ranked_metrics_and_module_available() -> None:
    assert cli._format_ranked_metrics([]) == "nenhum dado ainda"
    assert cli._format_ranked_metrics([{"claude-sonnet-4": 2}]) == "claude-sonnet-4 (2)"


def test_build_long_instruction_and_tty_support(monkeypatch) -> None:
    instruction = cli._build_long_instruction(
        [
            {"name": "Claude Code", "value": "claude-code", "description": "Anthropic"},
            {"name": "Codex", "value": "codex", "description": "OpenAI"},
        ]
    )
    monkeypatch.setattr(cli.sys.stdin, "isatty", lambda: False)
    monkeypatch.setattr(cli.sys.stdout, "isatty", lambda: False)

    assert "Claude Code: Anthropic" in instruction
    assert cli._supports_interactive_selection() is False


def test_prompt_single_selection_supports_value_and_name_fallback(
    monkeypatch,
) -> None:
    monkeypatch.setattr(cli, "_supports_interactive_selection", lambda: False)
    monkeypatch.setattr("builtins.input", lambda _prompt: "alpha")

    by_value = cli._prompt_single_selection(
        message="Teste",
        choices=[
            {"name": "Alpha", "value": "alpha", "description": "ok"},
            {"name": "Beta", "value": "beta", "description": "stop"},
        ],
        instruction="x",
    )

    monkeypatch.setattr("builtins.input", lambda _prompt: "Beta")
    by_name = cli._prompt_single_selection(
        message="Teste",
        choices=[
            {"name": "Alpha", "value": "alpha", "description": "ok"},
            {"name": "Beta", "value": "beta", "description": "stop"},
        ],
        instruction="x",
    )

    assert by_value == "alpha"
    assert by_name == "beta"


def test_prompt_single_selection_uses_inquirer_when_tty(monkeypatch) -> None:
    monkeypatch.setattr(cli, "_supports_interactive_selection", lambda: True)

    class FakePrompt:
        def execute(self):
            return ["codex"]

    monkeypatch.setattr(cli.inquirer, "checkbox", lambda **_kwargs: FakePrompt())

    result = cli._prompt_single_selection(
        message="Teste",
        choices=[{"name": "Codex", "value": "codex", "description": "OpenAI"}],
        instruction="x",
    )

    assert result == "codex"


def test_read_optional_text_uses_inquirer(monkeypatch) -> None:
    monkeypatch.setattr(cli, "_supports_interactive_selection", lambda: True)

    class FakePrompt:
        def __init__(self, value):
            self.value = value

        def execute(self):
            return self.value

    monkeypatch.setattr(cli.inquirer, "text", lambda **_kwargs: FakePrompt("system text"))

    assert cli._read_optional_text("x") == "system text"


def test_read_prompt_uses_inquirer(monkeypatch) -> None:
    monkeypatch.setattr(cli, "_supports_interactive_selection", lambda: True)

    class FakePrompt:
        def execute(self):
            return "prompt direto"

    monkeypatch.setattr(cli.inquirer, "text", lambda **_kwargs: FakePrompt())

    assert cli._read_prompt() == "prompt direto"


def test_choose_host_profile_retries_until_valid(
    monkeypatch, capsys: pytest.CaptureFixture[str]
) -> None:
    answers = iter(["999", "1"])
    monkeypatch.setattr("builtins.input", lambda _prompt: next(answers))
    monkeypatch.setattr(cli, "_supports_interactive_selection", lambda: False)

    profile = cli._choose_host_profile()

    output = capsys.readouterr().out
    assert profile.id == "claude-code"
    assert "Opcao invalida. Escolha um provider valido." in output


def test_interactive_review_cancel_and_empty_prompt(monkeypatch) -> None:
    monkeypatch.setattr(cli, "_choose_host_profile", lambda: cli.HOST_PROFILES[0])
    monkeypatch.setattr(cli, "_choose_model", lambda _profile: None)
    assert cli._interactive_review(False) == 1

    monkeypatch.setattr(
        cli,
        "_choose_model",
        lambda _profile: type(
            "M",
            (),
            {"provider": "anthropic", "model": "claude-sonnet-4"},
        )(),
    )
    monkeypatch.setattr(cli, "_read_prompt", lambda: "")
    assert cli._interactive_review(False) == 1


def test_interactive_review_run_path(monkeypatch) -> None:
    monkeypatch.setattr(cli, "_choose_host_profile", lambda: cli.HOST_PROFILES[1])
    monkeypatch.setattr(
        cli,
        "_choose_model",
        lambda _profile: type(
            "M",
            (),
            {"provider": "openai", "model": "gpt-4.1"},
        )(),
    )
    monkeypatch.setattr(cli, "_read_prompt", lambda: "Prompt")
    monkeypatch.setattr(cli, "_read_optional_text", lambda _prompt: "")
    monkeypatch.setattr(cli, "_read_optional_float", lambda *_args, **_kwargs: None)
    monkeypatch.setattr(cli, "_run_command", lambda args: 0 if args.provider == "openai" else 1)

    assert cli._interactive_review(True) == 0


def test_interactive_review_uses_automatic_output_token_estimate(monkeypatch) -> None:
    monkeypatch.setattr(cli, "_choose_host_profile", lambda: cli.HOST_PROFILES[0])
    monkeypatch.setattr(
        cli,
        "_choose_model",
        lambda _profile: type(
            "M",
            (),
            {"provider": "anthropic", "model": "claude-sonnet-4"},
        )(),
    )
    monkeypatch.setattr(cli, "_read_prompt", lambda: "Prompt")

    captured: dict[str, object] = {}

    def fake_review(args):
        captured["estimated_output_tokens"] = args.estimated_output_tokens
        return 0

    monkeypatch.setattr(cli, "_review_and_maybe_cancel", fake_review)

    assert cli._interactive_review(False) == 0
    assert captured["estimated_output_tokens"] is None
