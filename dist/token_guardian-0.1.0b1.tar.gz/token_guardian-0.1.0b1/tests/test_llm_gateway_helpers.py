from __future__ import annotations

from types import SimpleNamespace

import pytest

import app.services.llm_gateway_service as llm_gateway_service


def test_to_litellm_model_name_for_openai() -> None:
    assert llm_gateway_service._to_litellm_model_name("openai", "gpt-4.1") == "gpt-4.1"


def test_build_messages_appends_extra_messages() -> None:
    extra = [SimpleNamespace(role="system", content="Responda em portugues.")]
    result = llm_gateway_service._build_messages("Prompt base.", extra)

    assert result[0] == {"role": "user", "content": "Prompt base."}
    assert result[1] == {"role": "system", "content": "Responda em portugues."}


def test_extract_text_content_raises_without_choices() -> None:
    with pytest.raises(llm_gateway_service.GatewayDependencyError):
        llm_gateway_service._extract_text_content(SimpleNamespace(choices=[]))


def test_extract_text_content_raises_without_message_content() -> None:
    response = SimpleNamespace(choices=[SimpleNamespace(message=SimpleNamespace(content=None))])
    with pytest.raises(llm_gateway_service.GatewayDependencyError):
        llm_gateway_service._extract_text_content(response)


def test_coerce_raw_response_supports_dict() -> None:
    payload = {"id": "123"}
    assert llm_gateway_service._coerce_raw_response(payload) == payload


def test_load_litellm_completion_raises_when_missing(monkeypatch) -> None:
    monkeypatch.setattr(
        llm_gateway_service, "import_module", lambda _name: (_ for _ in ()).throw(ImportError)
    )

    with pytest.raises(llm_gateway_service.GatewayDependencyError):
        llm_gateway_service._load_litellm_completion()
