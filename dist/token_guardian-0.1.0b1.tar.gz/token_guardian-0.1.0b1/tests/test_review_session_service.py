from __future__ import annotations

import pytest

from app.models.schemas import ReviewSessionCreateRequest
from app.services.review_session_service import (
    ReviewSessionNotFoundError,
    create_review_session,
    get_review_session,
    render_review_session_response,
)


def test_review_session_is_created_as_reviewed() -> None:
    response = create_review_session(
        ReviewSessionCreateRequest(
            provider="anthropic",
            model="claude-sonnet-4",
            prompt="Revise esta arquitetura e estime custo.",
        )
    )

    assert response.status == "reviewed"
    assert response.decision_required is False
    assert response.should_call_llm is True
    assert response.stop_chat is False
    assert response.session_id


def test_review_session_renders_final_markdown() -> None:
    review = create_review_session(
        ReviewSessionCreateRequest(
            provider="anthropic",
            model="claude-sonnet-4",
            prompt="Revise esta arquitetura e estime custo.",
        )
    )

    response = render_review_session_response(review.session_id, "Resposta final.")

    assert response.status == "completed"
    assert response.should_call_llm is False
    assert "## Resposta da LLM" in response.markdown


def test_review_session_get_returns_error_for_missing_id() -> None:
    with pytest.raises(ReviewSessionNotFoundError):
        get_review_session("missing-session")
