from __future__ import annotations

from app.models.schemas import (
    AnalyzePromptRequest,
    ReviewLLMResponseRequest,
)
from app.services.analyzer_service import analyze_prompt
from app.services.review_service import review_llm_response


def test_analyze_prompt_returns_expected_payload() -> None:
    response = analyze_prompt(
        AnalyzePromptRequest(
            provider="anthropic",
            model="claude-sonnet-4",
            prompt="Explique a arquitetura do sistema.\nExplique a arquitetura do sistema.",
            estimated_output_tokens=800,
        )
    )

    assert response.input_tokens > 0
    assert response.estimated_output_tokens == 800
    assert response.estimated_total_tokens == response.input_tokens + 800
    assert response.context_limit == 200_000
    assert response.estimated_cost_usd > 0
    assert response.risk_level in {"low", "medium", "high", "critical"}
    assert response.context_health_score <= 100
    assert response.suggestions


def test_review_llm_response_returns_analysis_before_any_llm_output() -> None:
    response = review_llm_response(
        ReviewLLMResponseRequest(
            provider="anthropic",
            model="claude-sonnet-4",
            prompt="Revise esta arquitetura e estime custo.",
        )
    )

    assert response.status == "reviewed"
    assert response.content_type == "markdown"
    assert response.decision_required is False
    assert response.stop_chat is False
    assert response.should_call_llm is True
    assert response.llm_response is None
    assert "A analise foi concluida" in response.markdown


def test_review_llm_response_returns_output_after_llm_completion() -> None:
    response = review_llm_response(
        ReviewLLMResponseRequest(
            provider="anthropic",
            model="claude-sonnet-4",
            prompt="Revise esta arquitetura e estime custo.",
            llm_response="Arquitetura revisada com sucesso.",
        )
    )

    assert response.status == "completed"
    assert response.content_type == "markdown"
    assert response.decision_required is False
    assert response.stop_chat is False
    assert response.should_call_llm is False
    assert response.llm_response == "Arquitetura revisada com sucesso."
    assert "## Resposta da LLM" in response.markdown
