from __future__ import annotations

from types import SimpleNamespace

import pytest

from app.models.schemas import ReviewSessionCreateRequest, ReviewSessionInvokeRequest
from app.services.llm_gateway_service import (
    GatewayDependencyError,
    invoke_reviewed_session,
)
from app.services.review_session_service import (
    create_review_session,
    get_review_session,
)
import app.services.llm_gateway_service as llm_gateway_service


def test_invoke_returns_gateway_error_without_litellm(monkeypatch) -> None:
    review = create_review_session(
        ReviewSessionCreateRequest(
            provider="anthropic",
            model="claude-sonnet-4",
            prompt="Revise esta arquitetura e estime custo.",
        )
    )

    def fake_loader():
        raise GatewayDependencyError("LiteLLM missing.")

    monkeypatch.setattr(llm_gateway_service, "_load_litellm_completion", fake_loader)

    with pytest.raises(GatewayDependencyError, match="LiteLLM missing."):
        invoke_reviewed_session(review.session_id, ReviewSessionInvokeRequest())


def test_invoke_calls_litellm_after_review(monkeypatch) -> None:
    review = create_review_session(
        ReviewSessionCreateRequest(
            provider="anthropic",
            model="claude-sonnet-4",
            prompt="Revise esta arquitetura e estime custo.",
        )
    )
    captured: dict[str, object] = {}

    def fake_completion(**kwargs):
        captured.update(kwargs)
        return SimpleNamespace(
            choices=[
                SimpleNamespace(
                    message=SimpleNamespace(content="Resposta final da LLM.")
                )
            ],
            model_dump=lambda: {
                "choices": [{"message": {"content": "Resposta final da LLM."}}]
            },
        )

    monkeypatch.setattr(
        llm_gateway_service, "_load_litellm_completion", lambda: fake_completion
    )

    response = invoke_reviewed_session(
        review.session_id,
        ReviewSessionInvokeRequest(
            messages=[{"role": "system", "content": "Responda em portugues."}],
            temperature=0.2,
            max_tokens=256,
        ),
    )
    session = get_review_session(review.session_id)

    assert response.status == "completed"
    assert response.content == "Resposta final da LLM."
    assert response.provider == "anthropic"
    assert response.model == "claude-sonnet-4"
    assert captured["model"] == "anthropic/claude-sonnet-4"
    assert captured["temperature"] == 0.2
    assert captured["max_tokens"] == 256
    assert captured["messages"][0] == {
        "role": "user",
        "content": "Revise esta arquitetura e estime custo.",
    }
    assert captured["messages"][1] == {
        "role": "system",
        "content": "Responda em portugues.",
    }
    assert session.status == "completed"
