from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field


RiskLevel = Literal["low", "medium", "high", "critical"]
ComplexityLevel = Literal["Simple", "Medium", "Complex", "Very Complex"]
CostScore = Literal["$", "$$", "$$$", "$$$$"]


class AnalyzePromptRequest(BaseModel):
    provider: str = Field(..., examples=["anthropic"])
    model: str = Field(..., examples=["claude-sonnet-4"])
    prompt: str = Field(..., min_length=1)
    estimated_output_tokens: int | None = Field(default=None, ge=1)


class AnalyzePromptResponse(BaseModel):
    provider: str
    model: str
    input_tokens: int
    estimated_output_tokens: int
    estimated_total_tokens: int
    context_limit: int
    context_usage_percent: float
    estimated_cost_usd: float
    risk_level: RiskLevel
    context_health_score: int
    cost_score: CostScore
    complexity_score: ComplexityLevel
    suggestions: list[str]


ReviewStatus = Literal["reviewed", "completed"]


class ReviewLLMResponseRequest(BaseModel):
    provider: str = Field(..., examples=["anthropic"])
    model: str = Field(..., examples=["claude-sonnet-4"])
    prompt: str = Field(..., min_length=1)
    llm_response: str | None = Field(default=None, min_length=1)
    estimated_output_tokens: int | None = Field(default=None, ge=1)


class ReviewSessionCreateRequest(BaseModel):
    provider: str = Field(..., examples=["anthropic"])
    model: str = Field(..., examples=["claude-sonnet-4"])
    prompt: str = Field(..., min_length=1)
    estimated_output_tokens: int | None = Field(default=None, ge=1)


class LLMMessage(BaseModel):
    role: Literal["system", "user", "assistant"]
    content: str = Field(..., min_length=1)


class ReviewSessionInvokeRequest(BaseModel):
    messages: list[LLMMessage] = Field(default_factory=list)
    temperature: float | None = Field(default=None, ge=0, le=2)
    max_tokens: int | None = Field(default=None, ge=1)
    demo_mode: bool = False


class ReviewLLMResponseResult(BaseModel):
    status: ReviewStatus
    content_type: Literal["markdown"]
    decision_required: bool
    stop_chat: bool
    should_call_llm: bool
    markdown: str
    analysis: AnalyzePromptResponse
    llm_response: str | None = None


class ReviewSessionResponse(BaseModel):
    session_id: str
    status: ReviewStatus
    content_type: Literal["markdown"]
    markdown: str
    decision_required: bool
    should_call_llm: bool
    stop_chat: bool


class LLMInvocationResponse(BaseModel):
    session_id: str
    status: ReviewStatus
    provider: str
    model: str
    content: str
    raw_response: dict[str, object]


class MetricsResponse(BaseModel):
    total_requests: int
    total_tokens: int
    total_cost_estimated: float
    top_models: list[dict[str, int]]
    top_providers: list[dict[str, int]]
