from __future__ import annotations

from importlib import import_module
from typing import Any

from app.models.schemas import LLMInvocationResponse, ReviewSessionInvokeRequest
from app.services.database import get_connection
from app.services.review_session_service import (
    get_review_session_record,
    render_review_session_response,
)


class GatewayDependencyError(RuntimeError):
    """Raised when the optional gateway dependency is not installed."""


def invoke_reviewed_session(
    session_id: str, request: ReviewSessionInvokeRequest
) -> LLMInvocationResponse:
    session = get_review_session_record(session_id)

    completion = _load_litellm_completion()
    model_name = _to_litellm_model_name(session["provider"], session["model"])
    messages = _build_messages(session["prompt"], request.messages)
    response = completion(
        model=model_name,
        messages=messages,
        temperature=request.temperature,
        max_tokens=request.max_tokens,
    )
    content = _extract_text_content(response)
    _mark_session_completed(session_id)
    render_review_session_response(session_id, content)

    return LLMInvocationResponse(
        session_id=session_id,
        status="completed",
        provider=session["provider"],
        model=session["model"],
        content=content,
        raw_response=_coerce_raw_response(response),
    )


def _load_litellm_completion():
    try:
        module = import_module("litellm")
    except ImportError as exc:
        raise GatewayDependencyError(
            "LiteLLM is not installed. Install with `pip install -e .[gateway]`."
        ) from exc

    completion = getattr(module, "completion", None)
    if completion is None:
        raise GatewayDependencyError("LiteLLM is installed but `completion` was not found.")
    return completion


def _to_litellm_model_name(provider: str, model: str) -> str:
    if provider == "openai":
        return model
    return f"{provider}/{model}"


def _build_messages(
    prompt: str, extra_messages: list[Any]
) -> list[dict[str, str]]:
    messages = [{"role": "user", "content": prompt}]
    messages.extend(
        {"role": message.role, "content": message.content} for message in extra_messages
    )
    return messages


def _extract_text_content(response: Any) -> str:
    choices = getattr(response, "choices", None)
    if not choices:
        raise GatewayDependencyError("LiteLLM returned no choices.")
    message = getattr(choices[0], "message", None)
    if message is None or getattr(message, "content", None) is None:
        raise GatewayDependencyError("LiteLLM returned no message content.")
    return str(message.content)


def _coerce_raw_response(response: Any) -> dict[str, object]:
    if hasattr(response, "model_dump"):
        return dict(response.model_dump())
    if isinstance(response, dict):
        return dict(response)
    return {"repr": repr(response)}


def _mark_session_completed(session_id: str) -> None:
    with get_connection() as conn:
        conn.execute(
            """
            UPDATE review_sessions
            SET status = 'completed', updated_at = CURRENT_TIMESTAMP
            WHERE session_id = ?
            """,
            (session_id,),
        )
        conn.commit()
