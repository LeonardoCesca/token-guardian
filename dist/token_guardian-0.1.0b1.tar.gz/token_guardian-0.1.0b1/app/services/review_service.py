from __future__ import annotations

from app.models.schemas import (
    AnalyzePromptRequest,
    AnalyzePromptResponse,
    ReviewLLMResponseRequest,
    ReviewLLMResponseResult,
)
from app.services.analyzer_service import analyze_prompt


def review_llm_response(request: ReviewLLMResponseRequest) -> ReviewLLMResponseResult:
    analysis = analyze_prompt(
        AnalyzePromptRequest(
            provider=request.provider,
            model=request.model,
            prompt=request.prompt,
            estimated_output_tokens=request.estimated_output_tokens,
        )
    )

    if request.llm_response is None:
        return ReviewLLMResponseResult(
            status="reviewed",
            content_type="markdown",
            decision_required=False,
            stop_chat=False,
            should_call_llm=True,
            markdown=_build_review_markdown(analysis),
            analysis=analysis,
        )

    return ReviewLLMResponseResult(
        status="completed",
        content_type="markdown",
        decision_required=False,
        stop_chat=False,
        should_call_llm=False,
        markdown=_build_completed_markdown(analysis, request.llm_response),
        analysis=analysis,
        llm_response=request.llm_response,
    )


def _build_review_markdown(analysis: AnalyzePromptResponse) -> str:
    suggestions = "\n".join(f"- {item}" for item in analysis.suggestions)
    return (
        "## Analise da Resposta\n\n"
        f"**Provider:** `{analysis.provider}`  \n"
        f"**Model:** `{analysis.model}`  \n"
        f"**Tokens estimados:** `{analysis.estimated_total_tokens}` "
        f"({analysis.input_tokens} entrada + {analysis.estimated_output_tokens} saida)  \n"
        f"**Uso de contexto:** `{analysis.context_usage_percent:.2f}%` de `{analysis.context_limit}`  \n"
        f"**Custo estimado:** `${analysis.estimated_cost_usd:.6f}`  \n"
        f"**Risco:** `{analysis.risk_level}`  \n"
        f"**Saude do contexto:** `{analysis.context_health_score}/100`  \n"
        f"**Complexidade:** `{analysis.complexity_score}`  \n"
        f"**Faixa de custo:** `{analysis.cost_score}`\n\n"
        "### Recomendacoes\n"
        f"{suggestions}\n\n"
        "### Fluxo\n"
        "A analise foi concluida."
    )


def _build_completed_markdown(
    analysis: AnalyzePromptResponse, llm_response: str
) -> str:
    header = _build_review_markdown(analysis)
    return f"{header}\n\n---\n\n## Resposta da LLM\n\n{llm_response}"
