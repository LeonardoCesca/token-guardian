from __future__ import annotations

import sqlite3
from uuid import uuid4

from app.models.schemas import (
    ReviewLLMResponseRequest,
    ReviewSessionCreateRequest,
    ReviewSessionResponse,
)
from app.services.database import get_connection, init_db
from app.services.review_service import review_llm_response


class ReviewSessionNotFoundError(ValueError):
    """Raised when a review session does not exist."""


def create_review_session(request: ReviewSessionCreateRequest) -> ReviewSessionResponse:
    init_db()
    session_id = str(uuid4())
    with get_connection() as conn:
        conn.execute(
            """
            INSERT INTO review_sessions (
                session_id, provider, model, prompt, estimated_output_tokens, status
            )
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                session_id,
                request.provider,
                request.model,
                request.prompt,
                request.estimated_output_tokens,
                "reviewed",
            ),
        )
        conn.commit()

    return _build_session_response(session_id)


def get_review_session(session_id: str) -> ReviewSessionResponse:
    init_db()
    return _build_session_response(session_id)


def get_review_session_record(session_id: str) -> sqlite3.Row:
    init_db()
    return _get_session_row(session_id)


def render_review_session_response(
    session_id: str, llm_response: str
) -> ReviewSessionResponse:
    init_db()
    session = _get_session_row(session_id)

    result = review_llm_response(
        ReviewLLMResponseRequest(
            provider=session["provider"],
            model=session["model"],
            prompt=session["prompt"],
            estimated_output_tokens=session["estimated_output_tokens"],
            llm_response=llm_response,
        )
    )
    with get_connection() as conn:
        conn.execute(
            """
            UPDATE review_sessions
            SET llm_response = ?, status = 'completed', updated_at = CURRENT_TIMESTAMP
            WHERE session_id = ?
            """,
            (llm_response, session_id),
        )
        conn.commit()
    return ReviewSessionResponse(
        session_id=session_id,
        status="completed",
        content_type=result.content_type,
        markdown=result.markdown,
        decision_required=result.decision_required,
        should_call_llm=result.should_call_llm,
        stop_chat=result.stop_chat,
    )


def _build_session_response(session_id: str) -> ReviewSessionResponse:
    session = _get_session_row(session_id)
    result = review_llm_response(
        ReviewLLMResponseRequest(
            provider=session["provider"],
            model=session["model"],
            prompt=session["prompt"],
            estimated_output_tokens=session["estimated_output_tokens"],
            llm_response=session["llm_response"],
        )
    )
    return ReviewSessionResponse(
        session_id=session_id,
        status=session["status"],
        content_type=result.content_type,
        markdown=result.markdown,
        decision_required=result.decision_required,
        should_call_llm=result.should_call_llm,
        stop_chat=result.stop_chat,
    )


def _get_session_row(session_id: str) -> sqlite3.Row:
    with get_connection() as conn:
        row = conn.execute(
            """
            SELECT session_id, provider, model, prompt, estimated_output_tokens, llm_response, status
            FROM review_sessions
            WHERE session_id = ?
            """,
            (session_id,),
        ).fetchone()
    if row is None:
        raise ReviewSessionNotFoundError(f"Review session not found: {session_id}")
    return row
